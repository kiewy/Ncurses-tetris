extern const int block_square[4][4]; 

extern const int block_I[4][4]; 

extern const int block_T[4][4]; 

extern const int block_S[4][4]; 

extern const int block_Z[4][4]; 

extern const int block_L[4][4]; 

extern const int block_J[4][4]; 
