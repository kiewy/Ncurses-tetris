void keyHandler(int key,
                int block_active[4][4], int block_next[4][4],
                int iarr_field[], int iarr_tempField[], int i_fieldHeight, int i_fieldWidth,
                int * ip_activeYpos, int * ip_activeXpos, int i_col,
                int * score, int i_blockPoints, int *ip_blockType, int * ip_blockTypeNext,
				double * dp_dropTime);
